﻿using System.Windows;

namespace Xilium.CefGlue.WPF
{
    /// <summary>
    /// Interaction logic for WpfCefJSAlert.xaml
    /// </summary>
    public partial class WpfCefJSAlert : Window
    {
        public WpfCefJSAlert(string message)
        {
            InitializeComponent();
            this.messageTextBlock.Text = message;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }
    }
}
